package com.capgemini;



import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Wallet;



@Configuration

@ComponentScan(basePackages="com.capgemini")
public class AppConfig {

    @Bean(value="map")
	public Map<String,Customer> getMap(){
		
		Map<String, Customer> m = new HashMap<String,Customer>();
		m.put("1212121212", new Customer("Riya","1212121212",new Wallet(new BigDecimal(500))));
		
		return m;
	}
}
