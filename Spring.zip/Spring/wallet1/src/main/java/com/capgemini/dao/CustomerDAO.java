package com.capgemini.dao;

import java.math.BigDecimal;
import java.util.Map;

import com.capgemini.bean.Customer;

public interface CustomerDAO {

	
	Customer save(Customer customer);

	Customer findByMobileNumber(String mobileNumber);

	Customer updateCustomerWalletBalance(String mobileNumber,BigDecimal amount);
	
	public void setCustomerData(Map<String, Customer> customerData);
	
}
