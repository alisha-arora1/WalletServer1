package com.capgemini.ui;

import java.math.BigDecimal;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.capgemini.bean.Customer;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InvalidInputException;
import com.capgemini.service.CustomerService;
import com.capgemini.service.CustomerServiceImpl;

public class Client {
	
    public static void main(String[] args) throws InsufficientBalanceException, InvalidInputException {
  
		
		GenericXmlApplicationContext ctx= new GenericXmlApplicationContext("beanconfig.xml");
		
    	CustomerService customerService= ctx.getBean("service",CustomerServiceImpl.class); 
    	Customer customer;
    	
    	customerService.createAccount("Alisha","9012594604",new BigDecimal(1000));
		System.out.println("Account is created");
		customerService.createAccount("Rama","1234567890",new BigDecimal(2000));
		System.out.println("Account is created");
		customerService.createAccount("Jyoti","2345678901",new BigDecimal(3000));
		System.out.println("Account is created");
		
		
		customer = customerService.showBalance("9012594604");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		customer = customerService.showBalance("1234567890");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		customer = customerService.showBalance("2345678901");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		System.out.println("\n");
		
		//using xml
		customer = customerService.showBalance("1111111111");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		customer = customerService.showBalance("2222222222");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		customer = customerService.showBalance("3333333333");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		customer = customerService.showBalance("4444444444");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		customer = customerService.showBalance("5555555555");
		System.out.println("Balance= " + customer.getWallet().getBalance() );
		ctx.close();
		
    }
  
}