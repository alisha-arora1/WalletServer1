package com.capgemini.main;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Wallet;
import com.capgemini.service.CustomerService;
import com.capgemini.service.CustomerServiceImpl;
public class WalletServerMain {
public static void main( String[] args )
 {
	CustomerService customerService;
	Map<String,Customer> data=new HashMap<String, Customer>();
	
	     customerService=new CustomerServiceImpl(data);
	     String mobileNo;
		 Customer customer ;
		 
		 BigDecimal b1=new BigDecimal("100");
		 Customer customer1=customerService.createAccount("Alisha","9012594604",b1);
	     System.out.println(customer1.getName()+",Account is created");
	     
	     BigDecimal b2=new BigDecimal("200");
	     Customer customer2=customerService.createAccount("Ram","1234567890",b2);
		 System.out.println(customer2.getName()+",Account is created");
		 
		 BigDecimal b3=new BigDecimal("300");
	     Customer customer3=customerService.createAccount("Sita","2345678901",b3);
	     System.out.println(customer3.getName()+",Account is created");
	     
	     BigDecimal b4=new BigDecimal("400");
         Customer customer4=customerService.createAccount("Laxmi","3456789012",b4);
         System.out.println(customer4.getName()+",Account is created");
		 
		 BigDecimal b5=new BigDecimal("500");
	     Customer customer5=customerService.createAccount("Jyoti","4567890123",b5);
	     System.out.println(customer5.getName()+",Account is created");
	     
	customer=customerService.showBalance("9012594604");
	System.out.println("Balance for mobile number "+ customer.getMobileNumber()+" is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("1234567890");
	System.out.println("Balance for mobile number "+ customer.getMobileNumber()+" is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("2345678901");
	System.out.println("Balance for mobile number "+ customer.getMobileNumber()+" is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("3456789012");
	System.out.println("Balance for mobile number "+ customer.getMobileNumber()+" is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("4567890123");
	System.out.println("Balance for mobile number "+ customer.getMobileNumber()+" is "+customer.getWallet().getBalance());
	   }
}
		
			
			
			
			
			
			
			
