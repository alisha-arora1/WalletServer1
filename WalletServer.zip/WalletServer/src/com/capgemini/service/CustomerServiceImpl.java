package com.capgemini.service;

import java.math.BigDecimal;
import java.util.Map;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Wallet;
import com.capgemini.dao.CustomerDao;
import com.capgemini.dao.CustomerDaoImpl;


public class CustomerServiceImpl implements CustomerService{
	

	
	private CustomerDao customerdao;
	private CustomerDao dao;
	public CustomerServiceImpl(Map<String, Customer> data){
		dao= new CustomerDaoImpl(data);
	}
	public CustomerServiceImpl(CustomerDao dao) 
	{
		super();
		this.dao = dao;
	}

	
	public Customer createAccount(String customerName,String mobileNumber, BigDecimal balance)
	{
		Customer customer=null;
		customer=new Customer(customerName,mobileNumber,new Wallet(balance, null));
		dao.save(customer);
		return customer;
		
		
	}
	
	public Customer showBalance(String mobileNumber) 
	{
		Customer customer=null;
		customer=dao.findByMobileNumber(mobileNumber);
		return customer;
		}
	/*public Customer depositAmount(String mobileNumber, BigDecimal balance)
	public Customer fundTransfer(String mobileNumber, String mobileNumber1)
	public Customer showTransactions(String mobileNumber)*/
}
