package com.capgemini.service;

import java.math.BigDecimal;

import com.capgemini.bean.Customer;

public interface CustomerService {
	public Customer createAccount(String mobileNumber,String customerName, BigDecimal balance);
	public Customer showBalance(String mobileNumber);
/*	public Customer depositAmount(String mobileNumber, BigDecimal balance);
	public Customer fundTransfer(String mobileNumber, String mobileNumber1);
	public Customer showTransactions(String mobileNumber);
*/

}
