package com.capgemini.dao;

import java.math.BigDecimal;

import com.capgemini.bean.Customer;

public interface CustomerDao {
	public Customer save(Customer customer);

	public Customer findByMobileNumber(String mobileNumber);

	public Customer updateCustomerWalletBalance(String mobileNumber,BigDecimal amount);



}
